import React, { Component } from 'react';

export default class Registro extends Component {
  
    render() {
        return (
            <div>
                {/* <button>{this.props.tablero}</button> */}
                {/* {console.log(this.props.tablero)} */}
            </div>
        )
    }
}