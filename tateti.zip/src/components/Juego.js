import React, { Component } from 'react';
import Tablero from './Tablero';

export default class Juego extends Component {
    constructor(props){   //Todas las clases de componentes de React que tienen un constructor deben empezar con una llamada a super(props)
        super(props);
        this.state = {  //lo que viene en el componente por default
            tablero: Array(9).fill(null), //se crea un array con 9 index cada uno con valor null
            jugador : 'X',    //se crea el jugador inicial que arranca en X 
            ganador : null,
            ganadorMsj : "",
            history: []
        }
    }

    handleClick(c){

        let newTablero = this.state.tablero;   //crea una variable para un nuevo estado

        let newJugador = this.state.jugador === "X" ? "O" : "X";

        if(this.state.tablero[c] === null  && !this.state.ganador){  
            newTablero[c] = this.state.jugador; //asigna a cada index una X 
            this.setState({   //setState es una funcion que modifica el estado inicial(this.state)   
                tablero: newTablero,
                jugador: newJugador
            })
            this.checkWinner();
        }
    }

    resetGame(){
        this.tablero=["qsdad", 123123];  
        console.log(this.tablero);  
    }


    render() {       
        
        const Casilla = this.state.tablero.map((casilla,c) => //c = devuelve el valor de index del array
        <div className="box" key={c} 
            onClick={()=> this.handleClick(c)}>{casilla}    
        </div>
    )  //se crea cada casilla mapeando el array del state
        
        return (
            <div>
                <Tablero className="ganaste" Casilla={Casilla} tablero={this.state.tablero} jugador={this.state.jugador} ganador={this.state.ganador} ganadorMsj={this.state.ganadorMsj} history={this.state.history} />
            </div>
        )
    }
}
